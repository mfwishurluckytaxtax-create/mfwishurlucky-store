# MFwishurlucky — ติดตั้งผ่าน Android + GitHub Codespaces

> ใช้ GitHub Codespaces เป็นสภาพแวดล้อมชั่วคราวเพื่อเผยแพร่เว็บไซต์ขึ้น **Cloudflare Workers**; เมื่อเผยแพร่แล้วลูกค้าจะเข้าเว็บไซต์ที่ Cloudflare (ไม่ต้องเปิด Codespace ตลอดเวลา)

## เตรียมบัญชี

1. สมัคร GitHub Free: https://github.com/signup
2. สมัคร Cloudflare Free: https://dash.cloudflare.com/sign-up
3. ใช้ Chrome Android และเปิด **เว็บไซต์สำหรับเดสก์ท็อป** ถ้าปุ่มแสดงไม่ครบ
4. ไม่มีความจำเป็นต้องซื้อโดเมนหรือ GitHub Pro; Codespaces มีโควตาฟรีและอาจหยุดให้ใช้เมื่อครบโควตา

## สร้าง Codespace

1. ไป https://github.com/new สร้าง repository ใหม่ชื่อ `mfwishurlucky-store` ตั้ง **Private** และทำเครื่องหมาย Add a README file
2. เปิดหน้า repository > **Code** > **Codespaces** > **Create codespace on main** (หรือ https://github.com/codespaces แล้วเลือกสร้างใหม่)
3. เมื่อเปิด VS Code แบบเว็บแล้ว ที่แถบ Explorer เลือกโฟลเดอร์โปรเจกต์ แล้วเลือก **Upload...**; อัปโหลด ZIP ที่ดาวน์โหลดจาก ChatGPT เข้า Codespace อย่าอัปโหลดไฟล์ secret
4. เปิดเมนู **Terminal > New Terminal** แล้วรันคำสั่งต่อไปนี้:

```bash
unzip MFwishurlucky-GitHub-Android-Ready.zip
cd mf-final
npm install
npx wrangler login --device --browser=false
```

5. หน้าจอจะแสดง URL กับรหัสชั่วคราวของ Cloudflare: เปิด URL ใน Chrome หน้าต่าง/แท็บใหม่และอนุมัติ ไม่ต้องส่งรหัสให้ใคร
6. หลังแสดง `Successfully logged in` แล้วกลับ Codespaces และรัน:

```bash
npm run deploy
```

7. Cloudflare อาจขอให้เปิดใช้ subdomain `workers.dev`; ทำตามลิงก์ที่ระบบแจ้งโดยใช้บัญชี Cloudflare ของคุณ
8. ผลลัพธ์ควรมี URL `https://mfwishurlucky.<account>.workers.dev`; เข้า `/admin.html` เพื่อสร้าง Admin ด้วย Setup Token ที่แสดงใน Terminal
9. **สำรอง** `.mf-deploy-secrets.json` เป็นส่วนตัว แยกจาก GitHub และ Codespaces; อย่า commit/upload/share ไฟล์นี้

## สำคัญ

- ตั้ง repository เป็น **Private** และห้าม commit ของสำคัญ เช่น `APP_ENCRYPTION_KEY`, `INITIAL_SETUP_TOKEN`, Brevo API Key, credentials, `.mf-deploy-secrets.json`, `.dev.vars`, `.env`
- หลังติดตั้ง ให้ตรวจสอบหลังบ้านและทดลองคำสั่งซื้อก่อนเปิดขายจริง
- ระบบนี้ **ไม่ตรวจสอบการจ่ายเงินกับธนาคารอัตโนมัติ** แอดมินต้องอนุมัติสลิปก่อนส่งสินค้า
- เมื่อเลิกใช้ Codespace ให้ **Stop** เพื่อประหยัดโควตา: https://github.com/codespaces
- ในกรณีหน้าอัปโหลด ZIP ทำไม่ได้บนมือถือ ให้เปิด Desktop site ใน Chrome ก่อน; หากยังไม่ได้สามารถนำ ZIP ขึ้น GitHub ผ่านขั้นตอนอื่นตามหน้าจอจริง
- ใช้โค้ด/คีย์ที่คุณมีสิทธิ์จำหน่ายตามเงื่อนไขผู้ให้บริการเท่านั้น

## หมายเหตุเรื่อง Setup Token

สคริปต์ติดตั้งอัปเดตให้สร้างไฟล์ลับ **ก่อน** สร้างฐานข้อมูล D1 และใช้การเข้าสู่ระบบ Cloudflare แบบ Device Authorization เพื่อรองรับมือถือ
