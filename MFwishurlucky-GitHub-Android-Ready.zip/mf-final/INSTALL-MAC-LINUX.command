#!/bin/bash
cd "$(dirname "$0")"
echo "MFwishurlucky - ติดตั้งเว็บไซต์ออนไลน์"
if ! command -v node >/dev/null 2>&1; then
  echo "ไม่พบ Node.js 20 LTS หรือใหม่กว่า กรุณาติดตั้งจาก https://nodejs.org/"
  read -p "กด Enter เพื่อปิดหน้าต่าง..."
  exit 1
fi
node -e "if (Number(process.versions.node.split('.')[0]) < 20) process.exit(1)" || { echo "กรุณาติดตั้ง Node.js 20 LTS หรือใหม่กว่า"; exit 1; }
npm install && node scripts/deploy.mjs
read -p "กด Enter เพื่อปิดหน้าต่าง..."
