@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo MFwishurlucky - ติดตั้งเว็บไซต์ออนไลน์
echo ================================================
where node >nul 2>nul
if errorlevel 1 (
  echo ไม่พบ Node.js กรุณาติดตั้ง Node.js 20 LTS หรือใหม่กว่า จาก https://nodejs.org/
  pause
  exit /b 1
)
node --version
node -e "if (Number(process.versions.node.split('.')[0]) < 20) process.exit(1)"
if errorlevel 1 (
  echo กรุณาติดตั้ง Node.js 20 LTS หรือใหม่กว่า
  pause
  exit /b 1
)
npm install
if errorlevel 1 (
  echo ติดตั้งแพ็กเกจไม่สำเร็จ
  pause
  exit /b 1
)
node scripts/deploy.mjs
if errorlevel 1 echo การติดตั้งไม่สำเร็จ กรุณาตรวจสอบข้อความด้านบน
pause
