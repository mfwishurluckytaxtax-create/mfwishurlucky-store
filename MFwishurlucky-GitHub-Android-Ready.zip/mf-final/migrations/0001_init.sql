PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS login_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  ip TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(username, ip, created_at);

CREATE TABLE IF NOT EXISTS order_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ip TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_attempts ON order_attempts(ip, created_at);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
  description TEXT NOT NULL DEFAULT '',
  short_code TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '#7C4DCE',
  image_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id, active, sort_order);

CREATE TABLE IF NOT EXISTS variants (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  duration TEXT NOT NULL DEFAULT '',
  price INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 0,
  delivery_mode TEXT NOT NULL DEFAULT 'manual' CHECK(delivery_mode IN ('manual','auto')),
  max_per_order INTEGER NOT NULL DEFAULT 10,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_variants_product ON variants(product_id, active, sort_order);

CREATE TABLE IF NOT EXISTS inventory_codes (
  id TEXT PRIMARY KEY,
  variant_id TEXT NOT NULL REFERENCES variants(id) ON DELETE CASCADE,
  code_cipher TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','reserved','sold')),
  order_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_inventory_available ON inventory_codes(variant_id, status);
CREATE INDEX IF NOT EXISTS idx_inventory_order ON inventory_codes(order_id);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  order_no TEXT NOT NULL UNIQUE,
  lookup_token_hash TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  total INTEGER NOT NULL,
  payment_method TEXT NOT NULL CHECK(payment_method IN ('transfer','promptpay')),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK(payment_status IN ('pending','review','approved','rejected')),
  fulfillment_status TEXT NOT NULL DEFAULT 'pending' CHECK(fulfillment_status IN ('pending','ready','fulfilled','email_pending','awaiting_admin','cancelled')),
  payment_slip_id TEXT,
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(payment_status, fulfillment_status);

CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  variant_id TEXT NOT NULL,
  product_name TEXT NOT NULL,
  variant_name TEXT NOT NULL,
  duration TEXT NOT NULL DEFAULT '',
  unit_price INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  delivery_mode TEXT NOT NULL,
  delivery_payload_cipher TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS media (
  id TEXT PRIMARY KEY,
  mime_type TEXT NOT NULL,
  filename TEXT NOT NULL,
  data BLOB NOT NULL,
  is_private INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_media_private ON media(is_private);

CREATE TABLE IF NOT EXISTS email_logs (
  id TEXT PRIMARY KEY,
  order_id TEXT,
  recipient TEXT NOT NULL,
  subject TEXT NOT NULL,
  status TEXT NOT NULL,
  provider_message TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_email_logs_order ON email_logs(order_id, created_at DESC);

INSERT OR IGNORE INTO categories (id,name,sort_order,active,created_at) VALUES
('entertainment','Entertainment',1,1,datetime('now')),
('design','Design',2,1,datetime('now')),
('video','Video',3,1,datetime('now')),
('ai-tools','AI Tools',4,1,datetime('now')),
('productivity','Productivity',5,1,datetime('now'));

INSERT OR IGNORE INTO products (id,name,category_id,description,short_code,color,image_url,active,sort_order,created_at,updated_at) VALUES
('netflix','Netflix','entertainment','แพ็กเกจสตรีมมิงตามสิทธิ์ที่ร้านมีจำหน่าย','N','#E50914','',0,1,datetime('now'),datetime('now')),
('youtube','YouTube Premium','entertainment','แพ็กเกจ YouTube Premium ที่ร้านมีสิทธิ์จัดจำหน่าย','YT','#FF0033','',0,2,datetime('now'),datetime('now')),
('spotify','Spotify Premium','entertainment','แพ็กเกจฟังเพลงแบบพรีเมียม','S','#1DB954','',0,3,datetime('now'),datetime('now')),
('amazon-prime','Amazon Prime','entertainment','แพ็กเกจสตรีมมิง Amazon Prime','P','#19A8E0','',0,4,datetime('now'),datetime('now')),
('wetv','WeTV VIP','entertainment','แพ็กเกจ WeTV VIP','W','#19C5A0','',0,5,datetime('now'),datetime('now')),
('canva','Canva Pro','design','เครื่องมือออกแบบกราฟิกและคอนเทนต์','C','#7350DC','',0,1,datetime('now'),datetime('now')),
('capcut','CapCut Pro','video','เครื่องมือตัดต่อวิดีโอและสร้างคอนเทนต์','CC','#222222','',0,1,datetime('now'),datetime('now')),
('chatgpt','ChatGPT','ai-tools','ผู้ช่วย AI สำหรับงานและการเรียนรู้','AI','#168B6B','',0,1,datetime('now'),datetime('now')),
('microsoft365','Microsoft 365','productivity','ชุดเครื่องมือเพิ่มประสิทธิภาพการทำงาน','M','#2879DB','',0,1,datetime('now'),datetime('now'));

INSERT OR IGNORE INTO variants (id,product_id,name,duration,price,active,delivery_mode,max_per_order,sort_order,created_at,updated_at)
SELECT id||'-7d',id,'Premium 7 วัน','7 วัน',0,0,'manual',10,1,datetime('now'),datetime('now') FROM products;
INSERT OR IGNORE INTO variants (id,product_id,name,duration,price,active,delivery_mode,max_per_order,sort_order,created_at,updated_at)
SELECT id||'-30d',id,'Premium 30 วัน','30 วัน',0,0,'manual',10,2,datetime('now'),datetime('now') FROM products;

INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES
('store','{"name":"MFwishurlucky","tagline":"App Premium Store","notice":"ร้านค้าออนไลน์สำหรับบริการดิจิทัล","supportLine":"","facebook":""}',datetime('now')),
('payment','{"bankName":"","accountName":"","accountNumber":"","promptpay":"","qrImageUrl":"","instructions":"กรุณาตรวจสอบยอดเงินก่อนโอนและแนบสลิปทุกครั้ง"}',datetime('now')),
('theme','{"mode":"dark","preset":"gold","colors":{"primary":"#F5A623","secondary":"#F04D6D","background":"#0B0D12","surface":"#171421","button":"#FF8A00","text":"#FFFFFF","muted":"#B7ADBF","header":"#17111F","border":"#352A40"},"images":{"logo":"","hero":"","background":"","category":"","promo":""}}',datetime('now')),
('email','{"provider":"brevo","enabled":false,"fromName":"MFwishurlucky","fromEmail":"","adminEmail":"","apiKeyCipher":""}',datetime('now'));
