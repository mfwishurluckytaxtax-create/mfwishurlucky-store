import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const win = process.platform === 'win32';
const npm = win ? 'npx.cmd' : 'npx';
function run(args, options={}) {
  const r = spawnSync(npm, ['wrangler', ...args], { cwd: root, encoding: 'utf8', stdio: options.input !== undefined ? ['pipe','pipe','pipe'] : ['inherit','pipe','pipe'], input: options.input });
  if (options.capture) return { status:r.status, stdout:r.stdout||'', stderr:r.stderr||'' };
  if (r.stdout) process.stdout.write(r.stdout);
  if (r.stderr) process.stderr.write(r.stderr);
  if (r.status !== 0) throw new Error(`คำสั่ง wrangler ${args.join(' ')} ไม่สำเร็จ`);
  return {stdout:r.stdout||'',stderr:r.stderr||''};
}
function say(s=''){console.log(s)}
function readConfig(){return JSON.parse(readFileSync(resolve(root,'wrangler.json'),'utf8'))}
function saveConfig(c){writeFileSync(resolve(root,'wrangler.json'),JSON.stringify(c,null,2)+'\n')}

say('\nMFwishurlucky · ติดตั้งเว็บไซต์ออนไลน์แบบ Free Tier\n');
if (Number(process.versions.node.split('.')[0]) < 20) throw new Error('ต้องใช้ Node.js 20 LTS หรือใหม่กว่า กรุณาอัปเดต Node.js ก่อนติดตั้ง');
if(!existsSync(resolve(root,'node_modules/wrangler'))) {
  say('กำลังติดตั้งเครื่องมือ Cloudflare Wrangler...');
  const r=spawnSync(win?'npm.cmd':'npm',['install'],{cwd:root,stdio:'inherit'});
  if(r.status!==0) throw new Error('npm install ไม่สำเร็จ กรุณาติดตั้ง Node.js 20 LTS หรือใหม่กว่า');
}
let who=run(['whoami'],{capture:true});
if(who.status!==0){say('กรุณาอนุมัติเข้าสู่ระบบ Cloudflare ผ่านลิงก์และรหัสที่ Wrangler แสดง...');run(['login','--device','--browser=false']);}

let config=readConfig();
const creatingNewDatabase = config.d1_databases[0].database_id === 'REPLACE_WITH_D1_DATABASE_ID';
const secretFile=resolve(root,'.mf-deploy-secrets.json');
let secrets;
if (existsSync(secretFile)) {
  secrets=JSON.parse(readFileSync(secretFile,'utf8'));
} else {
  // Generate secrets BEFORE creating a database. This makes the first deployment
  // safe to resume if a later Cloudflare command fails halfway through.
  if (!creatingNewDatabase) throw new Error('พบฐานข้อมูลเดิมแต่ไม่พบไฟล์ .mf-deploy-secrets.json กรุณากู้คืนไฟล์สำรองเพื่อรักษากุญแจเข้ารหัสเดิม');
  secrets={APP_ENCRYPTION_KEY:randomBytes(32).toString('hex'),INITIAL_SETUP_TOKEN:randomBytes(24).toString('base64url'),createdAt:new Date().toISOString()};
  writeFileSync(secretFile,JSON.stringify(secrets,null,2)+'\n',{mode:0o600});
  try{chmodSync(secretFile,0o600)}catch{}
}

if(creatingNewDatabase){
  say('\nกำลังสร้างฐานข้อมูล D1 ฟรี...');
  const created=run(['d1','create','mfwishurlucky-db'],{capture:true});
  const output=(created.stdout||'')+'\n'+(created.stderr||'');
  const match=output.match(/database_id\s*=\s*"([a-f0-9-]+)"/i)||output.match(/database_id\s*:\s*"?([a-f0-9-]+)"?/i);
  if(!match) { process.stdout.write(output); throw new Error('อ่าน Database ID ไม่สำเร็จ กรุณารัน npx wrangler d1 create mfwishurlucky-db แล้วใส่ database_id ใน wrangler.json ด้วยตนเอง'); }
  config.d1_databases[0].database_id=match[1]; saveConfig(config); say('สร้างฐานข้อมูลเรียบร้อย');
} else say('พบฐานข้อมูลเดิมใน wrangler.json จะใช้ฐานข้อมูลเดิม');

say('\nกำลังเตรียมตารางฐานข้อมูล...');
run(['d1','migrations','apply','mfwishurlucky-db','--remote']);
say('\nกำลังเผยแพร่เว็บไซต์ครั้งแรก...');
const deployed=run(['deploy'],{capture:true});
if(deployed.status!==0) throw new Error('เผยแพร่เว็บไซต์ไม่สำเร็จ กรุณาตรวจสอบข้อผิดพลาดจาก Cloudflare');
process.stdout.write(deployed.stdout||''); if(deployed.stderr)process.stderr.write(deployed.stderr);
const all=(deployed.stdout||'')+'\n'+(deployed.stderr||'');
const urls=all.match(/https:\/\/[a-z0-9-]+\.[a-z0-9-]+\.workers\.dev/ig)||[];
say('\nกำลังตั้งค่าคีย์เข้ารหัสและ Setup Token...');
run(['secret','put','APP_ENCRYPTION_KEY'],{input:secrets.APP_ENCRYPTION_KEY+'\n'});
run(['secret','put','INITIAL_SETUP_TOKEN'],{input:secrets.INITIAL_SETUP_TOKEN+'\n'});
say('\nติดตั้งเสร็จแล้ว');
if(urls.length) say(`เว็บไซต์ของคุณ: ${urls[urls.length-1]}`);
say('หน้าแอดมิน: เพิ่ม /admin.html ต่อท้าย URL');
say('\nSetup Token (ใช้ครั้งเดียวตอนสร้างบัญชีแอดมิน):');
say(secrets.INITIAL_SETUP_TOKEN);
say(`เก็บไฟล์ ${secretFile} ไว้เป็นความลับและสำรองข้อมูล ห้ามส่งให้ผู้อื่นหรืออัปโหลดขึ้น GitHub`);
say('\nขั้นตอนถัดไป: เปิด /admin.html → ใส่ Setup Token → ตั้งชื่อผู้ใช้และรหัสผ่านแอดมิน (12 ตัวขึ้นไป) → ตั้งค่าการชำระเงินและ Brevo Email');
