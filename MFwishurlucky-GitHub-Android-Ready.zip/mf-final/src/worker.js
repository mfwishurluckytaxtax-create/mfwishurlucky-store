const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...headers }
});
const nowIso = () => new Date().toISOString();
const uid = () => crypto.randomUUID();
const enc = new TextEncoder();
const dec = new TextDecoder();
const b64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const unb64 = (s) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const hex = (bytes) => [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join('');
const fromHex = (s) => Uint8Array.from((s.match(/.{1,2}/g)||[]).map(x=>parseInt(x,16)));
const hash = async (value) => hex(await crypto.subtle.digest('SHA-256', enc.encode(value)));
const safeEqual = (a,b) => { if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let out=0;for(let i=0;i<a.length;i++)out|=a.charCodeAt(i)^b.charCodeAt(i);return out===0; };
const clean = (v, max=500) => String(v ?? '').trim().slice(0,max);
const money = (v) => Math.max(0, Math.round(Number(v)||0));
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||''));
const safeAssetUrl = (v) => { const s=clean(v,300); return s.startsWith('/media/') || /^https:\/\//i.test(s) ? s : ''; };
const escapeHtml = (s) => String(s??'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function bodyJson(req) { try { return await req.json(); } catch { throw new Error('ข้อมูลที่ส่งมาไม่ถูกต้อง'); } }
async function getSetting(db, key, fallback={}) {
  const row = await db.prepare('SELECT value FROM settings WHERE key=?').bind(key).first();
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch { return fallback; }
}
async function putSetting(db, key, value) {
  await db.prepare('INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')
    .bind(key, JSON.stringify(value), nowIso()).run();
}
function cookieValue(req, name) {
  const raw = req.headers.get('Cookie') || '';
  for (const part of raw.split(';')) { const [k,...v] = part.trim().split('='); if(k===name) return v.join('='); }
  return '';
}
function cookieHeader(value, maxAge, secure=true) {
  return `mf_session=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure?'; Secure':''}`;
}
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:unb64(salt),iterations:120000}, key, 256);
  return b64(bits);
}
async function makeSession(db, adminId, requestUrl) {
  const tokenBytes = crypto.getRandomValues(new Uint8Array(32));
  const token = b64(tokenBytes).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  const tokenHash = await hash(token);
  const expires = Math.floor(Date.now()/1000) + 60*60*24*7;
  await db.prepare('INSERT INTO sessions(id,admin_id,token_hash,expires_at,created_at) VALUES(?,?,?,?,?)')
    .bind(uid(),adminId,tokenHash,expires,nowIso()).run();
  return cookieHeader(token, 60*60*24*7, new URL(requestUrl).protocol === 'https:');
}
async function getAdmin(req, env) {
  const token = cookieValue(req,'mf_session'); if (!token) return null;
  const tokenHash = await hash(token);
  const row = await env.DB.prepare(`SELECT a.id,a.username,s.id AS session_id FROM sessions s JOIN admins a ON a.id=s.admin_id WHERE s.token_hash=? AND s.expires_at>? LIMIT 1`)
    .bind(tokenHash, Math.floor(Date.now()/1000)).first();
  return row || null;
}
async function requireAdmin(req, env) {
  const admin = await getAdmin(req,env);
  if (!admin) throw Object.assign(new Error('กรุณาเข้าสู่ระบบผู้ดูแล'),{status:401});
  return admin;
}
function assertSameOrigin(req, url) {
  const origin = req.headers.get('Origin');
  if (origin && origin !== url.origin) throw Object.assign(new Error('คำขอไม่ผ่านการตรวจสอบต้นทาง'),{status:403});
}
function encryptionKey(env) {
  const key = env.APP_ENCRYPTION_KEY || '';
  if (!/^[a-f0-9]{64}$/i.test(key)) throw new Error('ยังไม่ได้ตั้งค่า APP_ENCRYPTION_KEY บนระบบโฮสต์');
  return crypto.subtle.importKey('raw', fromHex(key), 'AES-GCM', false, ['encrypt','decrypt']);
}
async function encryptSecret(env, value) {
  if (!value) return '';
  const key = await encryptionKey(env), iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({name:'AES-GCM',iv}, key, enc.encode(value));
  return `${b64(iv)}.${b64(cipher)}`;
}
async function decryptSecret(env, value) {
  if (!value) return '';
  const [iv,cipher] = value.split('.');
  const key = await encryptionKey(env);
  const plain = await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(iv)}, key, unb64(cipher));
  return dec.decode(plain);
}
async function getEmailConfig(db, env) {
  const config = await getSetting(db,'email',{provider:'brevo',enabled:false,fromName:'MFwishurlucky',fromEmail:'',adminEmail:'',apiKeyCipher:''});
  return {...config, apiKey: await decryptSecret(env,config.apiKeyCipher||'')};
}
async function sendEmail(db, env, {to,subject,html,text,orderId=null}) {
  const cfg = await getEmailConfig(db,env);
  if (!cfg.enabled || !cfg.apiKey || !cfg.fromEmail || !emailOk(cfg.fromEmail)) return {ok:false, skipped:true, message:'ยังไม่ได้ตั้งค่าบริการอีเมล'};
  try {
    const res = await fetch('https://api.brevo.com/v3/smtp/email', {
      method:'POST', headers:{'accept':'application/json','api-key':cfg.apiKey,'content-type':'application/json'},
      body:JSON.stringify({sender:{name:cfg.fromName||'MFwishurlucky',email:cfg.fromEmail},to:[{email:to}],subject,htmlContent:html,textContent:text||''})
    });
    const payload = await res.json().catch(()=>({}));
    const ok = res.ok;
    await db.prepare('INSERT INTO email_logs(id,order_id,recipient,subject,status,provider_message,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(uid(),orderId,to,subject,ok?'sent':'failed',clean(payload.message||payload.messageId||JSON.stringify(payload),500),nowIso()).run();
    return {ok,message:payload.messageId||payload.message||`HTTP ${res.status}`};
  } catch (e) {
    await db.prepare('INSERT INTO email_logs(id,order_id,recipient,subject,status,provider_message,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(uid(),orderId,to,subject,'failed',clean(e.message,500),nowIso()).run();
    return {ok:false,message:e.message};
  }
}
function emailShell(title, body) {
  return `<!doctype html><html><body style="margin:0;background:#100d17;color:#f8f4ff;font-family:Arial,sans-serif;padding:24px"><div style="max-width:620px;margin:auto;background:#1a1424;border:1px solid #40304f;border-radius:18px;padding:26px"><div style="font-size:22px;font-weight:bold;color:#f5c46b">MFwishurlucky</div><h2 style="color:#fff">${escapeHtml(title)}</h2>${body}<p style="color:#a99eb9;font-size:12px;border-top:1px solid #40304f;padding-top:16px">อีเมลนี้ส่งโดยระบบร้านค้า MFwishurlucky</p></div></body></html>`;
}
async function mediaResponse(id, env, privateAllowed=false) {
  const row = await env.DB.prepare('SELECT mime_type,filename,data,is_private FROM media WHERE id=?').bind(id).first();
  if (!row || (row.is_private && !privateAllowed)) return new Response('Not found',{status:404});
  return new Response(row.data,{headers:{'content-type':row.mime_type,'cache-control':row.is_private?'no-store':'public, max-age=31536000, immutable','x-content-type-options':'nosniff','content-disposition':`inline; filename="${String(row.filename||'image').replace(/["\r\n]/g,'')}"`}});
}
async function uploadImage(file, env, isPrivate=false) {
  if (!file || typeof file.arrayBuffer!=='function') throw Object.assign(new Error('ไม่พบไฟล์ภาพ'),{status:400});
  if (file.size > 1_500_000) throw Object.assign(new Error('ไฟล์ต้องมีขนาดไม่เกิน 1.5 MB'),{status:413});
  const allowed = {'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
  const ext = allowed[file.type]; if(!ext) throw Object.assign(new Error('รองรับเฉพาะ JPG, PNG และ WebP'),{status:415});
  const bytes = new Uint8Array(await file.arrayBuffer());
  const isPng = bytes.length>=8 && [137,80,78,71,13,10,26,10].every((v,i)=>bytes[i]===v);
  const isJpeg = bytes.length>=3 && bytes[0]===255 && bytes[1]===216 && bytes[2]===255;
  const isWebp = bytes.length>=12 && String.fromCharCode(...bytes.slice(0,4))==='RIFF' && String.fromCharCode(...bytes.slice(8,12))==='WEBP';
  if (!(isPng||isJpeg||isWebp)) throw Object.assign(new Error('เนื้อหาไฟล์ไม่ใช่ภาพ JPG, PNG หรือ WebP ที่ถูกต้อง'),{status:415});
  const id = uid();
  await env.DB.prepare('INSERT INTO media(id,mime_type,filename,data,is_private,created_at) VALUES(?,?,?,?,?,?)')
    .bind(id,file.type,clean(file.name||`upload.${ext}`,120),bytes,isPrivate?1:0,nowIso()).run();
  return {id,url:isPrivate?'':`/media/${id}`};
}
async function publicStore(env) {
  const [store,payment,theme,cats,prods,vars] = await Promise.all([
    getSetting(env.DB,'store',{}),getSetting(env.DB,'payment',{}),getSetting(env.DB,'theme',{}),
    env.DB.prepare('SELECT id,name,sort_order FROM categories WHERE active=1 ORDER BY sort_order,name').all(),
    env.DB.prepare('SELECT * FROM products WHERE active=1 ORDER BY sort_order,name').all(),
    env.DB.prepare('SELECT * FROM variants WHERE active=1 AND price>0 ORDER BY sort_order,name').all()
  ]);
  const byProduct = new Map();
  for(const v of vars.results||[]) { if(!byProduct.has(v.product_id))byProduct.set(v.product_id,[]); byProduct.get(v.product_id).push({id:v.id,name:v.name,duration:v.duration,price:v.price,deliveryMode:v.delivery_mode,maxPerOrder:v.max_per_order}); }
  const products = (prods.results||[]).map(p=>({...p,variants:byProduct.get(p.id)||[]})).filter(p=>p.variants.length);
  return {store,payment:{bankName:payment.bankName||'',accountName:payment.accountName||'',accountNumber:payment.accountNumber||'',promptpay:payment.promptpay||'',qrImageUrl:payment.qrImageUrl||'',instructions:payment.instructions||''},theme,categories:cats.results||[],products};
}
async function adminCatalog(env) {
  const [cats,products,variants] = await Promise.all([
    env.DB.prepare('SELECT * FROM categories ORDER BY sort_order,name').all(),
    env.DB.prepare('SELECT * FROM products ORDER BY sort_order,name').all(),
    env.DB.prepare(`SELECT v.*, (SELECT COUNT(*) FROM inventory_codes c WHERE c.variant_id=v.id AND c.status='available') AS stock_count FROM variants v ORDER BY v.sort_order,v.name`).all()
  ]);
  const map = new Map(); for(const v of variants.results||[]){if(!map.has(v.product_id))map.set(v.product_id,[]);map.get(v.product_id).push(v)}
  return {categories:cats.results||[],products:(products.results||[]).map(p=>({...p,variants:map.get(p.id)||[]}))};
}
async function handleApi(req, env, url) {
  const path=url.pathname, method=req.method;
  if (method!=='GET' && method!=='HEAD') assertSameOrigin(req,url);
  if (path==='/api/health' && method==='GET') {
    const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();
    return json({ok:true,setupRequired:!count?.n,version:'1.0.0'});
  }
  if (path==='/api/setup' && method==='POST') {
    const data=await bodyJson(req); const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM admins').first();
    if(count?.n) return json({error:'ระบบตั้งค่าแอดมินแล้ว กรุณาเข้าสู่ระบบ'},409);
    if(!env.INITIAL_SETUP_TOKEN || !safeEqual(clean(data.setupToken,200),env.INITIAL_SETUP_TOKEN)) return json({error:'Setup token ไม่ถูกต้อง'},403);
    const username=clean(data.username,50), password=String(data.password||'');
    if(!/^[a-zA-Z0-9_.-]{4,50}$/.test(username)) return json({error:'ชื่อผู้ใช้ต้องมี 4–50 ตัวอักษร และใช้ a-z, 0-9, จุด ขีด หรือ _ เท่านั้น'},400);
    if(password.length<12 || password.length>128) return json({error:'รหัสผ่านต้องมีอย่างน้อย 12 ตัวอักษร'},400);
    const salt=b64(crypto.getRandomValues(new Uint8Array(16))); const passHash=await passwordHash(password,salt); const adminId=uid();
    await env.DB.prepare('INSERT INTO admins(id,username,password_hash,password_salt,created_at) VALUES(?,?,?,?,?)').bind(adminId,username,passHash,salt,nowIso()).run();
    await putSetting(env.DB,'setup_done',{done:true,at:nowIso()});
    const cookie=await makeSession(env.DB,adminId,req.url);
    return json({ok:true,username},200,{'set-cookie':cookie});
  }
  if (path==='/api/admin/login' && method==='POST') {
    const data=await bodyJson(req); const username=clean(data.username,50), password=String(data.password||'');
    const ip=req.headers.get('CF-Connecting-IP')||'unknown';
    await env.DB.prepare('DELETE FROM login_attempts WHERE created_at<?').bind(Math.floor(Date.now()/1000)-86400).run();
    const attempts=await env.DB.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE username=? AND ip=? AND created_at>?').bind(username,ip,Math.floor(Date.now()/1000)-900).first();
    if((attempts?.n||0)>=8) return json({error:'ลองเข้าสู่ระบบหลายครั้งเกินไป กรุณารอ 15 นาที'},429);
    const admin=await env.DB.prepare('SELECT * FROM admins WHERE username=?').bind(username).first();
    if(!admin || !safeEqual(await passwordHash(password,admin.password_salt),admin.password_hash)) {
      await env.DB.prepare('INSERT INTO login_attempts(username,ip,created_at) VALUES(?,?,?)').bind(username,ip,Math.floor(Date.now()/1000)).run();
      return json({error:'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'},401);
    }
    const cookie=await makeSession(env.DB,admin.id,req.url);
    return json({ok:true,username},200,{'set-cookie':cookie});
  }
  if(path==='/api/admin/logout' && method==='POST') {
    const token=cookieValue(req,'mf_session'); if(token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hash(token)).run();
    return json({ok:true},200,{'set-cookie':cookieHeader('',0,url.protocol==='https:')});
  }
  if(path==='/api/admin/me' && method==='GET') {
    const admin=await getAdmin(req,env); if(!admin)return json({ok:false},401); return json({ok:true,username:admin.username});
  }

  // All remaining admin endpoints require an authenticated session.
  if(path.startsWith('/api/admin/')) {
    const admin=await requireAdmin(req,env);
    if(path==='/api/admin/dashboard' && method==='GET') {
      const [orders,products,customers,revenue,pending]=await Promise.all([
        env.DB.prepare('SELECT COUNT(*) AS n FROM orders').first(),env.DB.prepare('SELECT COUNT(*) AS n FROM products').first(),env.DB.prepare('SELECT COUNT(DISTINCT customer_email) AS n FROM orders').first(),env.DB.prepare("SELECT COALESCE(SUM(total),0) AS n FROM orders WHERE payment_status='approved'").first(),env.DB.prepare("SELECT COUNT(*) AS n FROM orders WHERE payment_status IN ('pending','review')").first()
      ]);
      return json({orders:orders.n,products:products.n,customers:customers.n,revenue:revenue.n,pending:pending.n});
    }
    if(path==='/api/admin/catalog' && method==='GET') return json(await adminCatalog(env));
    if(path==='/api/admin/categories' && method==='POST') {
      const d=await bodyJson(req), id=uid(), name=clean(d.name,80); if(!name) return json({error:'กรุณาระบุชื่อหมวดหมู่'},400);
      await env.DB.prepare('INSERT INTO categories(id,name,sort_order,active,created_at) VALUES(?,?,?,?,?)').bind(id,name,Number(d.sortOrder)||0,d.active===false?0:1,nowIso()).run(); return json({ok:true,id});
    }
    const catMatch=path.match(/^\/api\/admin\/categories\/([^/]+)$/);
    if(catMatch && method==='PUT') { const d=await bodyJson(req); await env.DB.prepare('UPDATE categories SET name=?,sort_order=?,active=? WHERE id=?').bind(clean(d.name,80),Number(d.sortOrder)||0,d.active?1:0,catMatch[1]).run(); return json({ok:true}); }
    if(catMatch && method==='DELETE') { await env.DB.prepare('DELETE FROM categories WHERE id=?').bind(catMatch[1]).run(); return json({ok:true}); }
    if(path==='/api/admin/products' && method==='POST') {
      const d=await bodyJson(req), id=uid(), name=clean(d.name,100); if(!name)return json({error:'กรุณาระบุชื่อแอป'},400);
      await env.DB.prepare('INSERT INTO products(id,name,category_id,description,short_code,color,image_url,active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        .bind(id,name,d.categoryId||null,clean(d.description,1000),clean(d.shortCode,8),(/^#[0-9a-fA-F]{6}$/.test(String(d.color||''))?d.color:'#7C4DCE'),safeAssetUrl(d.imageUrl),d.active?1:0,Number(d.sortOrder)||0,nowIso(),nowIso()).run();
      return json({ok:true,id});
    }
    const productMatch=path.match(/^\/api\/admin\/products\/([^/]+)$/);
    if(productMatch && method==='PUT') { const d=await bodyJson(req); await env.DB.prepare('UPDATE products SET name=?,category_id=?,description=?,short_code=?,color=?,image_url=?,active=?,sort_order=?,updated_at=? WHERE id=?')
      .bind(clean(d.name,100),d.categoryId||null,clean(d.description,1000),clean(d.shortCode,8),(/^#[0-9a-fA-F]{6}$/.test(String(d.color||''))?d.color:'#7C4DCE'),safeAssetUrl(d.imageUrl),d.active?1:0,Number(d.sortOrder)||0,nowIso(),productMatch[1]).run(); return json({ok:true}); }
    if(productMatch && method==='DELETE') { await env.DB.prepare('DELETE FROM products WHERE id=?').bind(productMatch[1]).run(); return json({ok:true}); }
    if(path==='/api/admin/variants' && method==='POST') {
      const d=await bodyJson(req), id=uid(); if(!d.productId||!clean(d.name,100))return json({error:'กรุณาระบุสินค้าและชื่อแพ็กเกจ'},400);
      await env.DB.prepare('INSERT INTO variants(id,product_id,name,duration,price,active,delivery_mode,max_per_order,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        .bind(id,d.productId,clean(d.name,100),clean(d.duration,60),money(d.price),d.active?1:0,d.deliveryMode==='auto'?'auto':'manual',Math.max(1,Math.min(20,Number(d.maxPerOrder)||10)),Number(d.sortOrder)||0,nowIso(),nowIso()).run(); return json({ok:true,id});
    }
    const variantMatch=path.match(/^\/api\/admin\/variants\/([^/]+)$/);
    if(variantMatch && method==='PUT') { const d=await bodyJson(req); await env.DB.prepare('UPDATE variants SET name=?,duration=?,price=?,active=?,delivery_mode=?,max_per_order=?,sort_order=?,updated_at=? WHERE id=?')
      .bind(clean(d.name,100),clean(d.duration,60),money(d.price),d.active?1:0,d.deliveryMode==='auto'?'auto':'manual',Math.max(1,Math.min(20,Number(d.maxPerOrder)||10)),Number(d.sortOrder)||0,nowIso(),variantMatch[1]).run(); return json({ok:true}); }
    if(variantMatch && method==='DELETE') { await env.DB.prepare('DELETE FROM variants WHERE id=?').bind(variantMatch[1]).run(); return json({ok:true}); }
    const codesMatch=path.match(/^\/api\/admin\/variants\/([^/]+)\/codes$/);
    if(codesMatch && method==='POST') {
      const d=await bodyJson(req); const codes=String(d.codes||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).slice(0,500);
      if(!codes.length)return json({error:'กรุณาวางรหัสสินค้าอย่างน้อย 1 รายการ'},400);
      const exists=await env.DB.prepare('SELECT id FROM variants WHERE id=?').bind(codesMatch[1]).first(); if(!exists)return json({error:'ไม่พบแพ็กเกจ'},404);
      const stmts=[]; for(const code of codes) stmts.push(env.DB.prepare('INSERT INTO inventory_codes(id,variant_id,code_cipher,status,created_at,updated_at) VALUES(?,?,?,\'available\',?,?)').bind(uid(),codesMatch[1],await encryptSecret(env,code),nowIso(),nowIso()));
      await env.DB.batch(stmts); return json({ok:true,added:codes.length});
    }
    if(path==='/api/admin/orders' && method==='GET') {
      const rows=await env.DB.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 300').all();
      const items=await env.DB.prepare('SELECT * FROM order_items ORDER BY created_at').all();
      const by=new Map(); for(const i of items.results||[]){if(!by.has(i.order_id))by.set(i.order_id,[]);by.get(i.order_id).push(i)}
      return json({orders:(rows.results||[]).map(o=>({...o,items:by.get(o.id)||[]}))});
    }
    const slipMatch=path.match(/^\/api\/admin\/orders\/([^/]+)\/slip$/);
    if(slipMatch && method==='GET') { const o=await env.DB.prepare('SELECT payment_slip_id FROM orders WHERE id=?').bind(slipMatch[1]).first(); if(!o?.payment_slip_id)return new Response('Not found',{status:404}); return mediaResponse(o.payment_slip_id,env,true); }
    const approveMatch=path.match(/^\/api\/admin\/orders\/([^/]+)\/approve$/);
    if(approveMatch && method==='POST') return await approveOrder(approveMatch[1],env);
    const rejectMatch=path.match(/^\/api\/admin\/orders\/([^/]+)\/reject$/);
    if(rejectMatch && method==='POST') { await env.DB.prepare("UPDATE orders SET payment_status='rejected',fulfillment_status='cancelled',updated_at=? WHERE id=? AND payment_status!='approved'").bind(nowIso(),rejectMatch[1]).run(); return json({ok:true}); }
    const fulfillMatch=path.match(/^\/api\/admin\/orders\/([^/]+)\/fulfill$/);
    if(fulfillMatch && method==='POST') { const d=await bodyJson(req); const message=clean(d.message,5000); if(!message)return json({error:'กรุณากรอกรายละเอียดการส่งมอบ'},400); return await fulfillOrder(fulfillMatch[1],message,env); }
    const resendMatch=path.match(/^\/api\/admin\/orders\/([^/]+)\/resend$/);
    if(resendMatch && method==='POST') return await resendDelivery(resendMatch[1],env);
    if(path==='/api/admin/settings' && method==='GET') {
      const [store,payment,email,theme]=await Promise.all([getSetting(env.DB,'store',{}),getSetting(env.DB,'payment',{}),getSetting(env.DB,'email',{}),getSetting(env.DB,'theme',{})]);
      return json({store,payment,email:{provider:email.provider||'brevo',enabled:!!email.enabled,fromName:email.fromName||'MFwishurlucky',fromEmail:email.fromEmail||'',adminEmail:email.adminEmail||'',configured:!!email.apiKeyCipher},theme});
    }
    if(path==='/api/admin/settings' && method==='PUT') {
      const d=await bodyJson(req);
      if(d.store) await putSetting(env.DB,'store',{name:clean(d.store.name,100)||'MFwishurlucky',tagline:clean(d.store.tagline,120),notice:clean(d.store.notice,500),supportLine:clean(d.store.supportLine,100),facebook:safeAssetUrl(d.store.facebook),contactEmail:emailOk(d.store.contactEmail)?d.store.contactEmail:''});
      if(d.payment) await putSetting(env.DB,'payment',{bankName:clean(d.payment.bankName,80),accountName:clean(d.payment.accountName,100),accountNumber:clean(d.payment.accountNumber,50),promptpay:clean(d.payment.promptpay,50),qrImageUrl:safeAssetUrl(d.payment.qrImageUrl),instructions:clean(d.payment.instructions,500)});
      return json({ok:true});
    }
    if(path==='/api/admin/theme' && method==='PUT') { const d=await bodyJson(req); const colors={}; for(const k of ['primary','secondary','background','surface','button','text','muted','header','border']){const v=String(d.colors?.[k]||''); if(!/^#[0-9a-fA-F]{6}$/.test(v))return json({error:`ค่าสี ${k} ไม่ถูกต้อง`},400); colors[k]=v;}
      const images={}; for(const k of ['logo','hero','background','category','promo']) images[k]=String(d.images?.[k]||'').startsWith('/media/')?d.images[k]:'';
      await putSetting(env.DB,'theme',{mode:d.mode==='light'?'light':'dark',preset:clean(d.preset,30),colors,images}); return json({ok:true}); }
    if(path==='/api/admin/uploads' && method==='POST') { const form=await req.formData(); const result=await uploadImage(form.get('file'),env,false); return json(result); }
    if(path==='/api/admin/email' && method==='PUT') {
      const d=await bodyJson(req), old=await getSetting(env.DB,'email',{}); let apiKeyCipher=old.apiKeyCipher||'';
      if(clean(d.apiKey,500)) apiKeyCipher=await encryptSecret(env,clean(d.apiKey,500));
      const fromEmail=clean(d.fromEmail,150), adminEmail=clean(d.adminEmail,150);
      if(fromEmail&&!emailOk(fromEmail))return json({error:'อีเมลผู้ส่งไม่ถูกต้อง'},400);
      if(adminEmail&&!emailOk(adminEmail))return json({error:'อีเมลแจ้งเตือนแอดมินไม่ถูกต้อง'},400);
      await putSetting(env.DB,'email',{provider:'brevo',enabled:!!d.enabled,fromName:clean(d.fromName,100)||'MFwishurlucky',fromEmail,adminEmail,apiKeyCipher}); return json({ok:true,configured:!!apiKeyCipher});
    }
    if(path==='/api/admin/email/test' && method==='POST') { const d=await bodyJson(req); const to=clean(d.to,150); if(!emailOk(to))return json({error:'กรุณาระบุอีเมลปลายทางที่ถูกต้อง'},400); const r=await sendEmail(env.DB,env,{to,subject:'ทดสอบระบบอีเมล MFwishurlucky',html:emailShell('ทดสอบระบบอีเมลสำเร็จ',`<p>ระบบอีเมลของ MFwishurlucky สามารถส่งข้อความทดสอบได้แล้ว</p>`),text:'ทดสอบระบบอีเมล MFwishurlucky'}); return r.ok?json({ok:true,message:'ส่งอีเมลทดสอบแล้ว'}):json({error:r.message||'ส่งอีเมลไม่สำเร็จ'},400); }
    if(path==='/api/admin/password' && method==='PUT') { const d=await bodyJson(req); const current=String(d.currentPassword||''), next=String(d.newPassword||''); const row=await env.DB.prepare('SELECT * FROM admins WHERE id=?').bind(admin.id).first(); if(!row||!safeEqual(await passwordHash(current,row.password_salt),row.password_hash))return json({error:'รหัสผ่านปัจจุบันไม่ถูกต้อง'},403); if(next.length<12)return json({error:'รหัสผ่านใหม่ต้องมีอย่างน้อย 12 ตัวอักษร'},400); const salt=b64(crypto.getRandomValues(new Uint8Array(16))); await env.DB.prepare('UPDATE admins SET password_hash=?,password_salt=? WHERE id=?').bind(await passwordHash(next,salt),salt,admin.id).run(); await env.DB.prepare('DELETE FROM sessions WHERE admin_id=? AND id!=?').bind(admin.id,admin.session_id).run(); return json({ok:true}); }
    return json({error:'ไม่พบ API หลังบ้าน'},404);
  }

  // Public customer routes
  if(path==='/api/public/store' && method==='GET') return json(await publicStore(env));
  if(path==='/api/public/orders' && method==='POST') {
    const d=await bodyJson(req); const name=clean(d.customerName,100), email=clean(d.email,150), phone=clean(d.phone,40), methodPay=d.paymentMethod;
    const ip=req.headers.get('CF-Connecting-IP')||'unknown';
    await env.DB.prepare('DELETE FROM order_attempts WHERE created_at<?').bind(Math.floor(Date.now()/1000)-86400).run();
    const orderAttempts=await env.DB.prepare('SELECT COUNT(*) AS n FROM order_attempts WHERE ip=? AND created_at>?').bind(ip,Math.floor(Date.now()/1000)-3600).first();
    if((orderAttempts?.n||0)>=20)return json({error:'มีการส่งคำสั่งซื้อหลายครั้งเกินไป กรุณารอสักครู่แล้วลองใหม่'},429);
    await env.DB.prepare('INSERT INTO order_attempts(ip,created_at) VALUES(?,?)').bind(ip,Math.floor(Date.now()/1000)).run();
    if(!name||!emailOk(email)||phone.replace(/\D/g,'').length<8)return json({error:'กรุณากรอกชื่อ อีเมล และเบอร์โทรศัพท์ให้ถูกต้อง'},400);
    if(d.consent!==true)return json({error:'กรุณายอมรับนโยบายความเป็นส่วนตัวและเงื่อนไขการใช้บริการก่อนสั่งซื้อ'},400);
    if(!['transfer','promptpay'].includes(methodPay))return json({error:'กรุณาเลือกช่องทางชำระเงิน'},400);
    const paymentSettings=await getSetting(env.DB,'payment',{});
    if(methodPay==='transfer' && (!paymentSettings.accountNumber || !paymentSettings.accountName)) return json({error:'ร้านค้ายังไม่ได้ตั้งค่าบัญชีธนาคาร กรุณาติดต่อร้าน'},409);
    if(methodPay==='promptpay' && !paymentSettings.promptpay && !paymentSettings.qrImageUrl) return json({error:'ร้านค้ายังไม่ได้ตั้งค่า PromptPay QR กรุณาติดต่อร้าน'},409);
    if(!Array.isArray(d.items)||!d.items.length||d.items.length>15)return json({error:'ไม่พบรายการสินค้าในตะกร้า'},400);
    const lines=[]; let total=0;
    for(const raw of d.items){const qty=Math.max(1,Math.min(20,Math.floor(Number(raw.qty)||1))); const v=await env.DB.prepare(`SELECT v.*,p.name AS product_name,p.active AS product_active FROM variants v JOIN products p ON p.id=v.product_id WHERE v.id=?`).bind(clean(raw.variantId,100)).first();
      if(!v||!v.active||!v.product_active||v.price<=0)return json({error:'มีแพ็กเกจที่ไม่พร้อมจำหน่าย กรุณาปรับตะกร้าสินค้า'},409);
      if(qty>v.max_per_order)return json({error:`${v.name} ซื้อได้สูงสุด ${v.max_per_order} ชิ้นต่อคำสั่งซื้อ`},400);
      if(v.delivery_mode==='auto'){const stock=await env.DB.prepare("SELECT COUNT(*) AS n FROM inventory_codes WHERE variant_id=? AND status='available'").bind(v.id).first(); if((stock?.n||0)<qty)return json({error:`${v.name} มีสต็อกไม่เพียงพอ`},409);}
      lines.push({id:uid(),variantId:v.id,productName:v.product_name,variantName:v.name,duration:v.duration,unitPrice:v.price,quantity:qty,deliveryMode:v.delivery_mode}); total+=v.price*qty;
    }
    if(total<=0||total>100000000)return json({error:'ยอดสั่งซื้อไม่ถูกต้อง'},400);
    const orderId=uid(), date=new Date(), orderNo='MF'+date.toISOString().slice(2,10).replace(/-/g,'')+Math.random().toString(36).slice(2,7).toUpperCase();
    const tokenBytes=crypto.getRandomValues(new Uint8Array(32)); const accessToken=b64(tokenBytes).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); const tokenHash=await hash(accessToken);
    const statements=[env.DB.prepare("INSERT INTO orders(id,order_no,lookup_token_hash,customer_name,customer_email,customer_phone,total,payment_method,payment_status,fulfillment_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'pending','pending',?,?)").bind(orderId,orderNo,tokenHash,name,email,phone,total,methodPay,nowIso(),nowIso())];
    for(const l of lines)statements.push(env.DB.prepare('INSERT INTO order_items(id,order_id,variant_id,product_name,variant_name,duration,unit_price,quantity,delivery_mode,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(l.id,orderId,l.variantId,l.productName,l.variantName,l.duration,l.unitPrice,l.quantity,l.deliveryMode,nowIso()));
    await env.DB.batch(statements);
    const payment=paymentSettings; const store=await getSetting(env.DB,'store',{});
    const url=`${url.origin}/?order=${encodeURIComponent(orderNo)}&token=${encodeURIComponent(accessToken)}`;
    const itemHtml=lines.map(l=>`<li>${escapeHtml(l.productName)} — ${escapeHtml(l.variantName)} × ${l.quantity}: ฿${(l.unitPrice*l.quantity).toLocaleString('th-TH')}</li>`).join('');
    const emailResult=await sendEmail(env.DB,env,{to:email,orderId,subject:`ได้รับคำสั่งซื้อ ${orderNo} แล้ว`,html:emailShell('ได้รับคำสั่งซื้อแล้ว',`<p>สวัสดี ${escapeHtml(name)}</p><p>เลขคำสั่งซื้อ: <b>${orderNo}</b></p><ul>${itemHtml}</ul><h3>ยอดรวม ฿${total.toLocaleString('th-TH')}</h3><p>กรุณาชำระเงินและแนบหลักฐานผ่านลิงก์ด้านล่าง</p><p><a href="${escapeHtml(url)}" style="display:inline-block;background:#f5a623;color:#1a1025;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:bold">ดูคำสั่งซื้อและแนบสลิป</a></p>`),text:`ได้รับคำสั่งซื้อ ${orderNo} ยอดรวม ${total} บาท ดูรายละเอียด: ${url}`});
    return json({ok:true,orderNo,accessToken,total,paymentMethod:methodPay,payment,store,emailSent:!!emailResult.ok,orderUrl:url});
  }
  const orderMatch=path.match(/^\/api\/public\/orders\/([^/]+)$/);
  if(orderMatch && method==='GET') {
    const orderNo=decodeURIComponent(orderMatch[1]), token=url.searchParams.get('token')||''; const order=await env.DB.prepare('SELECT * FROM orders WHERE order_no=?').bind(orderNo).first();
    if(!order||!safeEqual(await hash(token),order.lookup_token_hash))return json({error:'ไม่พบคำสั่งซื้อหรือรหัสเข้าถึงไม่ถูกต้อง'},404);
    const items=await env.DB.prepare('SELECT * FROM order_items WHERE order_id=?').bind(order.id).all();
    const result=[]; for(const i of items.results||[]) result.push({productName:i.product_name,variantName:i.variant_name,duration:i.duration,unitPrice:i.unit_price,quantity:i.quantity,deliveryPayload:i.delivery_payload_cipher?await decryptSecret(env,i.delivery_payload_cipher).catch(()=> ''):''});
    return json({orderNo:order.order_no,customerName:order.customer_name,total:order.total,paymentMethod:order.payment_method,paymentStatus:order.payment_status,fulfillmentStatus:order.fulfillment_status,createdAt:order.created_at,items:result});
  }
  const slipMatch=path.match(/^\/api\/public\/orders\/([^/]+)\/slip$/);
  if(slipMatch && method==='POST') {
    const form=await req.formData(), token=clean(form.get('token'),200), file=form.get('file'), orderNo=decodeURIComponent(slipMatch[1]);
    const order=await env.DB.prepare('SELECT * FROM orders WHERE order_no=?').bind(orderNo).first(); if(!order||!safeEqual(await hash(token),order.lookup_token_hash))return json({error:'ไม่พบคำสั่งซื้อหรือรหัสเข้าถึงไม่ถูกต้อง'},404);
    if(order.payment_status==='approved')return json({error:'คำสั่งซื้อนี้ได้รับการยืนยันการชำระเงินแล้ว'},409);
    const media=await uploadImage(file,env,true);
    await env.DB.prepare("UPDATE orders SET payment_slip_id=?,payment_status='review',updated_at=? WHERE id=?").bind(media.id,nowIso(),order.id).run();
    const cfg=await getEmailConfig(env.DB,env); if(cfg.adminEmail) await sendEmail(env.DB,env,{to:cfg.adminEmail,orderId:order.id,subject:`มีสลิปใหม่สำหรับ ${orderNo}`,html:emailShell('มีหลักฐานการชำระเงินใหม่',`<p>คำสั่งซื้อ ${orderNo} มีการแนบสลิปแล้ว กรุณาตรวจสอบในหลังร้าน</p>`),text:`มีสลิปใหม่สำหรับ ${orderNo}`});
    return json({ok:true,message:'ส่งหลักฐานการชำระเงินแล้ว กรุณารอแอดมินตรวจสอบ'});
  }
  return json({error:'ไม่พบ API'},404);
}

async function approveOrder(orderId,env) {
  const db=env.DB, order=await db.prepare('SELECT * FROM orders WHERE id=?').bind(orderId).first();
  if(!order)return json({error:'ไม่พบคำสั่งซื้อ'},404);
  if(order.payment_status==='approved')return json({error:'คำสั่งซื้อนี้ได้รับการอนุมัติแล้ว'},409);
  const items=await db.prepare('SELECT * FROM order_items WHERE order_id=?').bind(orderId).all();
  const reserved=[];
  for(const item of items.results||[]) if(item.delivery_mode==='auto') {
    const rows=await db.prepare("SELECT id,code_cipher FROM inventory_codes WHERE variant_id=? AND status='available' ORDER BY created_at LIMIT ?").bind(item.variant_id,item.quantity).all();
    if((rows.results||[]).length<item.quantity)return json({error:`สต็อก ${item.variant_name} ไม่เพียงพอ ไม่สามารถอนุมัติและส่งอัตโนมัติได้`},409);
    reserved.push({item,rows:rows.results});
  }
  const stmts=[];
  for(const group of reserved) for(const row of group.rows) stmts.push(db.prepare("UPDATE inventory_codes SET status='sold',order_id=?,updated_at=? WHERE id=? AND status='available'").bind(orderId,nowIso(),row.id));
  if(stmts.length) {
    const results=await db.batch(stmts);
    const changed=results.reduce((n,r)=>n+(r.meta?.changes||0),0);
    if(changed!==stmts.length) { await db.prepare("UPDATE inventory_codes SET status='available',order_id=NULL,updated_at=? WHERE order_id=? AND status='sold'").bind(nowIso(),orderId).run(); return json({error:'สต็อกถูกใช้ไปแล้ว กรุณาตรวจสอบสต็อกก่อนยืนยันคำสั่งซื้อ'},409); }
  }
  for(const group of reserved) {
    const codes=[]; for(const row of group.rows) codes.push(await decryptSecret(env,row.code_cipher));
    const payload=`${group.item.product_name} — ${group.item.variant_name}\n${codes.map((c,i)=>`รายการ ${i+1}: ${c}`).join('\n')}`;
    await db.prepare('UPDATE order_items SET delivery_payload_cipher=? WHERE id=?').bind(await encryptSecret(env,payload),group.item.id).run();
  }
  const hasManual=(items.results||[]).some(i=>i.delivery_mode==='manual');
  await db.prepare("UPDATE orders SET payment_status='approved',fulfillment_status=?,updated_at=? WHERE id=?").bind(hasManual?'awaiting_admin':'ready',nowIso(),orderId).run();
  const payloads=await db.prepare('SELECT product_name,variant_name,delivery_payload_cipher FROM order_items WHERE order_id=?').bind(orderId).all();
  const delivery=(payloads.results||[]).filter(x=>x.delivery_payload_cipher).map(async x=>decryptSecret(env,x.delivery_payload_cipher));
  const decrypted=await Promise.all(delivery);
  const cfg=await getEmailConfig(db,env);
  const confirmation=hasManual?`<p>ยืนยันการชำระเงินสำหรับคำสั่งซื้อ ${order.order_no} แล้ว ร้านกำลังเตรียมรายละเอียดสินค้าและจะแจ้งให้ทราบอีกครั้ง</p>`:`<p>ยืนยันการชำระเงินสำหรับคำสั่งซื้อ ${order.order_no} แล้ว</p><pre style="white-space:pre-wrap;background:#100d17;padding:14px;border-radius:10px">${escapeHtml(decrypted.join('\n\n'))}</pre>`;
  const result=await sendEmail(db,env,{to:order.customer_email,orderId,subject:`ยืนยันการชำระเงิน ${order.order_no}`,html:emailShell('ยืนยันการชำระเงินแล้ว',confirmation),text:hasManual?`ยืนยันการชำระเงิน ${order.order_no} แล้ว ร้านกำลังเตรียมสินค้า`:`ยืนยันการชำระเงิน ${order.order_no}\n${decrypted.join('\n\n')}`});
  await db.prepare('UPDATE orders SET fulfillment_status=?,updated_at=? WHERE id=?').bind(hasManual?'awaiting_admin':(result.ok?'fulfilled':'email_pending'),nowIso(),orderId).run();
  return json({ok:true,message:hasManual?'ยืนยันชำระเงินแล้ว รอแอดมินส่งมอบแพ็กเกจที่ต้องจัดส่งเอง':result.ok?'ยืนยันและส่งอีเมลสินค้าแล้ว':'ยืนยันชำระเงินแล้ว แต่ส่งอีเมลไม่สำเร็จ สามารถกดส่งซ้ำได้',emailSent:!!result.ok});
}
async function fulfillOrder(orderId,message,env) {
  const db=env.DB, order=await db.prepare('SELECT * FROM orders WHERE id=?').bind(orderId).first(); if(!order)return json({error:'ไม่พบคำสั่งซื้อ'},404);
  if(order.payment_status!=='approved')return json({error:'ต้องยืนยันการชำระเงินก่อนส่งมอบสินค้า'},409);
  const items=await db.prepare("SELECT * FROM order_items WHERE order_id=? AND delivery_mode='manual'").bind(orderId).all();
  if(!(items.results||[]).length)return json({error:'ไม่มีรายการที่ต้องส่งมอบโดยแอดมิน'},409);
  const payload=await encryptSecret(env,message);
  for(const item of items.results) await db.prepare('UPDATE order_items SET delivery_payload_cipher=? WHERE id=?').bind(payload,item.id).run();
  return await resendDelivery(orderId,env);
}
async function resendDelivery(orderId,env) {
  const db=env.DB, order=await db.prepare('SELECT * FROM orders WHERE id=?').bind(orderId).first(); if(!order)return json({error:'ไม่พบคำสั่งซื้อ'},404);
  const rows=await db.prepare('SELECT * FROM order_items WHERE order_id=?').bind(orderId).all(); const parts=[];
  for(const item of rows.results||[]) if(item.delivery_payload_cipher) parts.push(await decryptSecret(env,item.delivery_payload_cipher));
  if(!parts.length)return json({error:'ยังไม่มีรายละเอียดส่งมอบสินค้า'},409);
  const html=`<p>รายละเอียดสินค้าสำหรับคำสั่งซื้อ ${order.order_no}</p>${parts.map(p=>`<pre style="white-space:pre-wrap;background:#100d17;padding:14px;border-radius:10px">${escapeHtml(p)}</pre>`).join('')}`;
  const result=await sendEmail(db,env,{to:order.customer_email,orderId,subject:`รายละเอียดสินค้า ${order.order_no} จาก MFwishurlucky`,html:emailShell('รายละเอียดสินค้าของคุณ',html),text:`${order.order_no}\n\n${parts.join('\n\n')}`});
  await db.prepare('UPDATE orders SET fulfillment_status=?,updated_at=? WHERE id=?').bind(result.ok?'fulfilled':'email_pending',nowIso(),orderId).run();
  return result.ok?json({ok:true,message:'ส่งอีเมลรายละเอียดสินค้าแล้ว'}):json({error:result.message||'ส่งอีเมลไม่สำเร็จ'},400);
}

export default {
  async fetch(request, env) {
    const url=new URL(request.url);
    try {
      if(url.pathname.startsWith('/api/')) return await handleApi(request,env,url);
      const mediaMatch=url.pathname.match(/^\/media\/([a-f0-9-]{36})$/i);
      if(mediaMatch && request.method==='GET') return await mediaResponse(mediaMatch[1],env,false);
      if(url.pathname==='/favicon.ico') return new Response(null,{status:204});
      return env.ASSETS.fetch(request);
    } catch(e) {
      const status=e.status||500;
      return json({error:status===500?'เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่อีกครั้ง':e.message||'เกิดข้อผิดพลาด'},status);
    }
  }
};
